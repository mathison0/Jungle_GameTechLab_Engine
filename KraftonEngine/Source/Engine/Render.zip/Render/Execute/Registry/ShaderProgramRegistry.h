#pragma once

#include "Render/Execute/Registry/ShaderProgramTypes.h"
#include "Render/Resources/Shaders/ShaderProgramDesc.h"

// FShaderProgramRegistry? ??? ???? ???????.
class FShaderProgramRegistry
{
public:
    void Initialize();

    const FGraphicsProgramDesc* Find(EShaderType InType) const;

private:
    void Add(EShaderType InType, const FGraphicsProgramDesc& Desc);

private:
    FGraphicsProgramDesc Descs[(uint32)EShaderType::MAX];
};
