#pragma once

enum class ERenderPipelineType
{
    DefaultRootPipeline,
    EditorRootPipeline,
    ScenePipeline,
    LitPipeline,
    UnlitPipeline,
    WorldNormalPipeline,
    SceneDepthPipeline,
    PostProcessPipeline,
    OverlayPipeline,
    PresentPipeline,
    Outline
};
