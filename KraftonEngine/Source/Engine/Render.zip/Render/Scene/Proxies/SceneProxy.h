﻿#pragma once

#include "Core/CoreTypes.h"
#include "Render/Scene/SceneProxyDirtyFlag.h"

// FSceneProxy? ? ??? ? ?????.
class FSceneProxy
{
public:
    virtual ~FSceneProxy() = default;

    void MarkDirty(ESceneProxyDirtyFlag Flag) { DirtyFlags |= Flag; }
    void ClearDirty(ESceneProxyDirtyFlag Flag) { DirtyFlags &= ~Flag; }
    bool IsDirty(ESceneProxyDirtyFlag Flag) const { return HasFlag(DirtyFlags, Flag); }
    bool IsAnyDirty() const { return DirtyFlags != ESceneProxyDirtyFlag::None; }

    uint32 ProxyId           = UINT32_MAX;
    uint32 SelectedListIndex = UINT32_MAX;

    ESceneProxyDirtyFlag DirtyFlags            = ESceneProxyDirtyFlag::All;
    bool                 bQueuedForDirtyUpdate = false;
};
