#pragma once

#include "Render/Scene/Proxies/Light/LightSceneProxy.h"

class UAmbientLightComponent;

// FAmbientLightSceneProxy? ???? ??? ? ?????.
class FAmbientLightSceneProxy : public FLightSceneProxy
{
public:
    FAmbientLightSceneProxy(UAmbientLightComponent* InComponent);
    ~FAmbientLightSceneProxy() override = default;

    void UpdateLightConstants() override;
    // 환경광은 공간 속성이 없으므로 Transform 갱신이 필요 없다.
    void UpdateTransform() override {}
};
