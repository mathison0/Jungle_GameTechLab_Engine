#pragma once

#include "Render/Scene/Proxies/SceneProxy.h"

// FSceneEffectProxy? ? ??? ?? ?????.
class FSceneEffectProxy : public FSceneProxy
{
public:
    virtual ~FSceneEffectProxy() = default;
};
