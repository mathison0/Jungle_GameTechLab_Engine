#pragma once

#include "Render/Scene/Proxies/Primitive/PrimitiveSceneProxy.h"

class UDecalComponent;

// FDecalSceneProxy? ?? ? ?????.
class FDecalSceneProxy : public FPrimitiveSceneProxy
{
public:
    FDecalSceneProxy(UDecalComponent* InComponent);
    ~FDecalSceneProxy() override;

    void UpdateTransform() override;
    void UpdateMaterial() override;
    void UpdateMesh() override;

private:
    UDecalComponent* GetDecalComponent() const;
    void             UpdateDecalConstants();

    FConstantBuffer* DecalCB;
    class UMaterial* DecalMaterial = nullptr;
};
