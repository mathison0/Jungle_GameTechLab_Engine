#pragma once

#include "Render/Scene/Proxies/Primitive/PrimitiveSceneProxy.h"

class UGizmoComponent;

// FGizmoSceneProxy? ??? ? ?????.
class FGizmoSceneProxy : public FPrimitiveSceneProxy
{
public:
    FGizmoSceneProxy(UGizmoComponent* InComponent, bool bInner = false);

    void UpdateMesh() override;
    void UpdatePerViewport(const FSceneView& SceneView) override;

private:
    UGizmoComponent* GetGizmoComponent() const;
    bool             bIsInner = false;
};
