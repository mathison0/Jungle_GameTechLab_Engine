#pragma once

#include "Render/Scene/Proxies/Primitive/BillboardSceneProxy.h"

class UCylindricalBillboardComponent;

// FCylindricalBillboardSceneProxy? ??? ??? ? ?????.
class FCylindricalBillboardSceneProxy : public FBillboardSceneProxy
{
public:
    FCylindricalBillboardSceneProxy(UCylindricalBillboardComponent* InComponent);

    void UpdateMesh() override;
    void UpdatePerViewport(const FSceneView& SceneView) override;
};
