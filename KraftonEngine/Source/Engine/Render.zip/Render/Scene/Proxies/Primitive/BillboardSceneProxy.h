#pragma once

#include "Render/Scene/Proxies/Primitive/PrimitiveSceneProxy.h"

class UBillboardComponent;

// FBillboardSceneProxy? ??? ? ?????.
class FBillboardSceneProxy : public FPrimitiveSceneProxy
{
public:
    FBillboardSceneProxy(UBillboardComponent* InComponent);

    void UpdateMesh() override;
    void UpdatePerViewport(const FSceneView& SceneView) override;

protected:
    UBillboardComponent* GetBillboardComponent() const;
};
