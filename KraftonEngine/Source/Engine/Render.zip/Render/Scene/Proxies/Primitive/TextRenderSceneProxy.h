#pragma once

#include "Render/Scene/Proxies/Primitive/PrimitiveSceneProxy.h"

class UTextRenderComponent;

// FTextRenderSceneProxy? ??? ?? ? ?????.
class FTextRenderSceneProxy : public FPrimitiveSceneProxy
{
public:
    FTextRenderSceneProxy(UTextRenderComponent* InComponent);

    void UpdateMesh() override;
    void UpdatePerViewport(const FSceneView& SceneView) override;

    FString CachedText;
    float   CachedFontScale = 1.0f;
    FVector CachedTextRight = FVector(0.0f, 1.0f, 0.0f);
    FVector CachedTextUp    = FVector(0.0f, 0.0f, 1.0f);
    FMatrix CachedTextWorldMatrix;

private:
    UTextRenderComponent* GetTextRenderComponent() const;
};
