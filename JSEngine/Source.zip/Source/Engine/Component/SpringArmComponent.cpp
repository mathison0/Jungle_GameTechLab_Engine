﻿#include "Component/SpringArmComponent.h"

#include "Object/ObjectFactory.h"

#include <cmath>
#include <cstring>

DEFINE_CLASS(USpringArmComponent, USceneComponent)
REGISTER_FACTORY(USpringArmComponent)

USpringArmComponent::USpringArmComponent()
{
	SetComponentTickEnabled(true);
}

void USpringArmComponent::PostEditProperty(const char* PropertyName)
{
	if (TargetArmLength < 0.0f)
	{
		TargetArmLength = 0.0f;
	}

	if (CameraLagSpeed < 0.01f)
	{
		CameraLagSpeed = 0.01f;
	}

	if (PropertyName == nullptr
		|| std::strcmp(PropertyName, "TargetArmLength") == 0
		|| std::strcmp(PropertyName, "SocketOffset") == 0
		|| std::strcmp(PropertyName, "bEnableCameraLag") == 0)
	{
		ResetCameraLag();
	}

	USceneComponent::PostEditProperty(PropertyName);
	UpdateSocketChildren();
}

void USpringArmComponent::UpdateWorldMatrix() const
{
	USceneComponent::UpdateWorldMatrix();
}

FVector USpringArmComponent::GetSocketLocalLocation() const
{
	return SocketOffset - FVector(TargetArmLength, 0.0f, 0.0f);
}

void USpringArmComponent::UpdateSocketChildren()
{
	FVector SocketLocalLocation = GetSocketLocalLocation();
	if (bEnableCameraLag && bLagLocationInitialized)
	{
		const FTransform ArmOriginTransform = GetWorldTransform();
		SocketLocalLocation = ArmOriginTransform.InverseTransformPosition(LagLocation);
	}

	for (USceneComponent* Child : ChildComponents)
	{
		if (Child)
		{
			Child->SetRelativeLocation(SocketLocalLocation);
		}
	}
}

void USpringArmComponent::AddYawInput(float DeltaYawDegrees)
{
	if (std::abs(DeltaYawDegrees) < 1e-6f)
	{
		return;
	}

	SetViewRotationDegrees(GetPitchDegrees(), GetYawDegrees() + DeltaYawDegrees);
}

void USpringArmComponent::AddPitchInput(float DeltaPitchDegrees)
{
	if (std::abs(DeltaPitchDegrees) < 1e-6f)
	{
		return;
	}

	SetViewRotationDegrees(GetPitchDegrees() + DeltaPitchDegrees, GetYawDegrees());
}

void USpringArmComponent::SetTargetArmLength(float InTargetArmLength)
{
	TargetArmLength = InTargetArmLength < 0.0f ? 0.0f : InTargetArmLength;
	ResetCameraLag();
	MarkTransformDirty();
	UpdateSocketChildren();
}

void USpringArmComponent::SetSocketOffset(const FVector& InSocketOffset)
{
	SocketOffset = InSocketOffset;
	ResetCameraLag();
	MarkTransformDirty();
	UpdateSocketChildren();
}

void USpringArmComponent::SetCameraLagEnabled(bool bEnabled)
{
	if (bEnableCameraLag != bEnabled)
	{
		bEnableCameraLag = bEnabled;
		ResetCameraLag();
		MarkTransformDirty();
		UpdateSocketChildren();
	}
}

void USpringArmComponent::SetCameraLagSpeed(float InCameraLagSpeed)
{
	CameraLagSpeed = InCameraLagSpeed < 0.01f ? 0.01f : InCameraLagSpeed;
}

void USpringArmComponent::TickComponent(float DeltaTime)
{
	if (!bEnableCameraLag)
	{
		bLagLocationInitialized = false;
		UpdateSocketChildren();
		return;
	}

	const FTransform DesiredTransform = CalculateDesiredSocketTransform();
	const FVector DesiredLocation = DesiredTransform.GetTranslation();

	if (!bLagLocationInitialized)
	{
		LagLocation = DesiredLocation;
		bLagLocationInitialized = true;
	}
	else
	{
		const float Alpha = MathUtil::Clamp(DeltaTime * CameraLagSpeed, 0.0f, 1.0f);
		LagLocation = FVector::Lerp(LagLocation, DesiredLocation, Alpha);
	}

	MarkTransformDirty();
	UpdateSocketChildren();
}

FTransform USpringArmComponent::CalculateDesiredSocketTransform() const
{
	const FTransform RelativeTransform = GetRelativeTransform();
	const FTransform ParentTransform = ParentComponent ? ParentComponent->GetWorldTransform() : FTransform::Identity;
	const FTransform ArmOriginTransform = RelativeTransform * ParentTransform;

	const FQuat ArmRotation = ArmOriginTransform.GetRotation();
	const FVector DesiredLocation = ArmOriginTransform.TransformPosition(GetSocketLocalLocation());

	return FTransform(ArmRotation, DesiredLocation, ArmOriginTransform.GetScale3D());
}

void USpringArmComponent::SetViewRotationDegrees(float PitchDegrees, float YawDegrees)
{
	PitchDegrees = MathUtil::Clamp(PitchDegrees, -89.0f, 89.0f);

	const float PitchRad = MathUtil::DegreesToRadians(PitchDegrees);
	const float YawRad = MathUtil::DegreesToRadians(YawDegrees);

	FVector Forward(
		std::cos(PitchRad) * std::cos(YawRad),
		std::cos(PitchRad) * std::sin(YawRad),
		std::sin(PitchRad));
	Forward = Forward.GetSafeNormal();

	FVector Right = FVector::CrossProduct(FVector::UpVector, Forward).GetSafeNormal();
	if (Right.IsNearlyZero())
	{
		return;
	}

	FVector Up = FVector::CrossProduct(Forward, Right).GetSafeNormal();

	FMatrix RotationMatrix = FMatrix::Identity;
	RotationMatrix.SetAxes(Forward, Right, Up);

	FQuat NewRotation(RotationMatrix);
	NewRotation.Normalize();
	SetRelativeRotationQuat(NewRotation);
}

float USpringArmComponent::GetPitchDegrees() const
{
	const FVector Forward = GetRelativeQuat().GetForwardVector().GetSafeNormal();
	return MathUtil::RadiansToDegrees(std::asin(MathUtil::Clamp(Forward.Z, -1.0f, 1.0f)));
}

float USpringArmComponent::GetYawDegrees() const
{
	const FVector Forward = GetRelativeQuat().GetForwardVector().GetSafeNormal();
	return MathUtil::RadiansToDegrees(std::atan2(Forward.Y, Forward.X));
}

void USpringArmComponent::ResetCameraLag()
{
	bLagLocationInitialized = false;
	LagLocation = FVector::ZeroVector;
}
