// AUTO-GENERATED FILE. DO NOT MODIFY.
#include "GameFramework/AActor.h"
#include "Core/Reflection/ReflectionRegistry.h"

struct Z_Construct_UClass_AActor {
    static FClassMetaData GetClassMetaData() {
        return FClassMetaData {
            "AActor",
            &AActor::s_TypeInfo,
            {
                { "bVisible", EPropertyType::Bool, offsetof(AActor, bVisible), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr },
                { "bIsActive", EPropertyType::Bool, offsetof(AActor, bIsActive), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr },
                { "bTickInEditor", EPropertyType::Bool, offsetof(AActor, bTickInEditor), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr }
            }
        };
    }
};

static FAutoClassRegister Z_Register_AActor_Var(Z_Construct_UClass_AActor::GetClassMetaData());
