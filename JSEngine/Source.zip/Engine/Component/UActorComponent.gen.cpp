// AUTO-GENERATED FILE. DO NOT MODIFY.
#include "Component/ActorComponent.h"
#include "Core/Reflection/ReflectionRegistry.h"

struct Z_Construct_UClass_UActorComponent {
    static FClassMetaData GetClassMetaData() {
        return FClassMetaData {
            "UActorComponent",
            &UActorComponent::s_TypeInfo,
            {
                { "bIsActive", EPropertyType::Bool, offsetof(UActorComponent, bIsActive), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr },
                { "bAutoActivate", EPropertyType::Bool, offsetof(UActorComponent, bAutoActivate), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr },
                { "bCanEverTick", EPropertyType::Bool, offsetof(UActorComponent, bCanEverTick), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr },
                { "bTransient", EPropertyType::Bool, offsetof(UActorComponent, bTransient), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr },
                { "bIsEditorOnly", EPropertyType::Bool, offsetof(UActorComponent, bIsEditorOnly), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, nullptr, nullptr }
            }
        };
    }
};

static FAutoClassRegister Z_Register_UActorComponent_Var(Z_Construct_UClass_UActorComponent::GetClassMetaData());
