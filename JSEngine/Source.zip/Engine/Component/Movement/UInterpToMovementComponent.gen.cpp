// AUTO-GENERATED FILE. DO NOT MODIFY.
#include "Component/Movement/InterpToMovementComponent.h"
#include "Core/Reflection/ReflectionRegistry.h"

static const FEnumValueMetaData Z_Enum_EInterpBehaviour_Values[] = {
    { "OneShot", "One Shot", 0 },
    { "OneShotReverse", "One Shot Reverse", 1 },
    { "Loop", "Loop", 2 },
    { "PingPong", "Ping Pong", 3 }
};
static const FEnumMetaData Z_Enum_EInterpBehaviour_Meta = { "EInterpBehaviour", static_cast<uint8>(sizeof(EInterpBehaviour)), Z_Enum_EInterpBehaviour_Values, 4 };

struct Z_Construct_UClass_UInterpToMovementComponent {
    static FClassMetaData GetClassMetaData() {
        return FClassMetaData {
            "UInterpToMovementComponent",
            &UInterpToMovementComponent::s_TypeInfo,
            {
                { "InterpBehaviour", EPropertyType::Enum, offsetof(UInterpToMovementComponent, InterpBehaviour), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, "Interp Mode", &Z_Enum_EInterpBehaviour_Meta }
            }
        };
    }
};

static FAutoClassRegister Z_Register_UInterpToMovementComponent_Var(Z_Construct_UClass_UInterpToMovementComponent::GetClassMetaData());
