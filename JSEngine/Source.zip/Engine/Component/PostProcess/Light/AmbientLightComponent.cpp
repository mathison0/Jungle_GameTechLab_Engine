﻿#include "AmbientLightComponent.h"

