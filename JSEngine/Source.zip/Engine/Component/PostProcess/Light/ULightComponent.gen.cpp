// AUTO-GENERATED FILE. DO NOT MODIFY.
#include "Component/PostProcess/Light/LightComponent.h"
#include "Core/Reflection/ReflectionRegistry.h"

static const FEnumValueMetaData Z_Enum_EShadowMap_Values[] = {
    { "CSM", "CSM", 0 },
    { "PSM", "PSM", 1 }
};
static const FEnumMetaData Z_Enum_EShadowMap_Meta = { "EShadowMap", static_cast<uint8>(sizeof(EShadowMap)), Z_Enum_EShadowMap_Values, 2 };

struct Z_Construct_UClass_ULightComponent {
    static FClassMetaData GetClassMetaData() {
        return FClassMetaData {
            "ULightComponent",
            &ULightComponent::s_TypeInfo,
            {
                { "ShadowMapType", EPropertyType::Enum, offsetof(ULightComponent, ShadowMapType), EPropertyUsageFlags::Editable, 0.0f, 0.0f, 0.1f, "ShadowMapType", &Z_Enum_EShadowMap_Meta }
            }
        };
    }
};

static FAutoClassRegister Z_Register_ULightComponent_Var(Z_Construct_UClass_ULightComponent::GetClassMetaData());
